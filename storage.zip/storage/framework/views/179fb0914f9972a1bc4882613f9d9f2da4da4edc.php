
<?php $__env->startSection('content'); ?>
    <div class="main-wrapper">	
        <div class="error-box">
            <h1>404</h1>
            <h3><i class="fa fa-warning"></i> Oops! Page not found!</h3>
            <p>The page you requested was not found.</p>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-custom">Back to Home</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.1\htdocs\hrmsserver\resources\views/errors/404.blade.php ENDPATH**/ ?>