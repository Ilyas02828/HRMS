<?php $__env->startSection('content'); ?>

    <style>
        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }
    </style>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-lists-center">
                    <div class="col">
                        <h3 class="page-title">Employee</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Employee</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_employee"><i class="fa fa-plus"></i> Add Employee</a>
                        <div class="view-icons">
                            <a href="<?php echo e(route('all/employee/card')); ?>" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>
                            <a href="<?php echo e(route('all/employee/list')); ?>" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>
                        </div>
                    </div>
                </div>
            </div>
			<!-- /Page Header -->
            <?php echo Toastr::message(); ?>

            <!-- Search Filter -->
            <form action="<?php echo e(route('all/employee/search')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row filter-row">
                    <div class="col-sm-4 col-md-4">
                        <div class="form-group form-focus">
                            <input type="text" class="form-control floating" name="employee_id">
                            <label class="focus-label">Employee ID</label>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4">
                        <div class="form-group form-focus">
                            <input type="text" class="form-control floating" name="name">
                            <label class="focus-label">Employee Name</label>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-1" ></div>
                    <div class="col-sm-4 col-md-3" >
                        <button type="sumit" class="btn btn-success btn-block"> Search </button>
                    </div>
                </div>
            </form>


            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Employee ID</th>
                                    <th>Iqama Number</th>
                                    <th>Iqama Type</th>
                                    <th>Iqama Expiry Date</th>

                                    <th>Mobile</th>
                                    <th>Nationality</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $style='';
                            ?>
                                <?php $__currentLoopData = $empList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr >
                                            <td><?php echo e($employee->id); ?></td>
                                            <td hidden class="id"><?php echo e($employee->id); ?></td>
                                            <td hidden class="employee_job_title"><?php echo e($employee->job_title); ?></td>
                                            <td hidden class="employee_company_site"><?php echo e($employee->company_site); ?></td>
                                            <td hidden class="employee_bank_name_code"><?php echo e($employee->bank_name_code); ?></td>
                                            <td hidden class="employee_account"><?php echo e($employee->account); ?></td>
                                            <td hidden class="employee_bank_address"><?php echo e($employee->bank_address); ?></td>


                                            <td class="employee_name"><?php echo e($employee->name); ?></td>
                                            <td class="employee_employee_id"><?php echo e($employee->employee_id); ?></td>
                                            <td class="employee_ecoma_number"><?php echo e($employee->ecoma_number); ?></td>
                                            <td class="employee_ecoma_type"><?php echo e($employee->ecoma_type); ?></td>
                                            <?php
                                                $currentDate = \Illuminate\Support\Carbon ::now();
                                                $expirationDate = \Illuminate\Support\Carbon::parse($employee->ecoma_expiry);
                                                $remainingDays = $currentDate->diffInDays($expirationDate);
                                                if ($remainingDays < 75){
                                                    $style = 'color: red; font-weight: bold;
                                                    animation: blinker 1s linear infinite;';
                                                } else {
                                                    $style='';
                                                }

                                            ?>
                                            <td class="employee_ecoma_expiry" style="<?php echo e($style); ?>"><?php echo e($employee->ecoma_expiry); ?></td>

                                            <td class="employee_contact"><?php echo e($employee->contact); ?></td>
                                            <td class="employee_nationality"><?php echo e($employee->nationality); ?></td>
                                            <td class="text-right">
                                                <div class="dropdown dropdown-action">
                                                        <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item" href="<?php echo e(url('all/employee/view/detail/'.$employee->id)); ?>"><i class="fa fa-eye m-r-5"></i> Detail</a>
                                                        <a class="dropdown-item  edit_employee" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                        <a class="dropdown-item delete_employee" href="<?php echo e(url('all/employee/delete', $employee->id)); ?>" class="btn btn-danger" data-confirm-delete="true"> <i class="fa fa-trash-o m-r-5"></i>Delete</a>

                                                    </div>
                                                    </div>
                                            </td>
                                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <!-- /Page Content -->

        <!-- Add Employee Modal -->
        <div id="add_employee" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Employee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('all/employee/save')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <h4>Basic Information</h4>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                    <label class="col-form-label">Full Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" id="name" name="name" placeholder="Employee Full Name">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Employee Unique ID <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="employee_id" name="employee_id" placeholder="Employee Unique ID">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Ecoma Number <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="ecoma_number" name="ecoma_number" placeholder="Ecoma Number">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Ecoma Type <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="ecoma_type" name="ecoma_type" placeholder="Ecoma Type">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Ecoma Expiry <span class="text-danger">*</span></label>
                                        <input class="form-control datetimepicker" type="text" id="ecoma_expiry" name="ecoma_expiry" placeholder="Ecoma Expiry">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Nationality <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="nationality" name="nationality" placeholder="Nationality">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Job Title <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="job_title" name="job_title" placeholder="Job Title">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Company / Site <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="    " name="company_site" placeholder="Company / Site">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Contact <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="contact" name="contact" placeholder="Contact Number">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Email <span class="text-danger">*</span></label>
                                        <input class="form-control" type="email" id="email" name="email" placeholder="Auto email">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="col-form-label">  Total Visa Fee </label>
                                        <input class="form-control" type="text" id="total_visa_fee" name="total_visa_fee" placeholder="Employee Total Visa Fee">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="col-form-label"> Due Visa Fee (if any)</label>
                                        <input class="form-control" type="text" id="due_visa_fee" name="due_visa_fee" placeholder="Employee Due Visa Fee">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Due Advance Salary (if any ) </label>
                                        <input class="form-control" type="text" id="due_advance_salary" name="due_advance_salary" placeholder="Advance salary given (if any)">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Month </label>
                                        <input class="form-control" type="text" id="advance_salary_month" name="advance_salary_month" placeholder="Advance salary given month ">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Regarding Project</label>
                                        <select class="select select2s-hidden-accessible" style="width: 100%;" tabindex="-1" aria-hidden="true" id="project_id_advance" name="project_id_advance" required">
                                        <option value="">-- Select --</option>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Previous Salary (if any ) </label>
                                        <input class="form-control" type="text" id="due_previous_salary" name="due_previous_salary" placeholder="Previous salary remaining (if any)">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Month </label>
                                        <input class="form-control" type="text" id="previous_salary_month" name="previous_salary_month" placeholder="Previous salary remaining for month">
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Regarding Project</label>
                                        <select class="select select2s-hidden-accessible" style="width: 100%;" tabindex="-1" aria-hidden="true" id="project_id_previous" name="project_id_previous" required">
                                        <option value="">-- Select --</option>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-12">
                                    <h4>Bank Details</h4>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Bank Name Code <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="bank_name_code" name="bank_name_code" placeholder="Bank Name Code">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Bank Address<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="bank_address" name="bank_address" placeholder="Bank Address">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Account<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="account" name="account" placeholder="Bank Account">
                                    </div>
                                </div>
                            </div>
                            <hr>
                        </div>
                            <div class="submit-section">
                                <button class="btn btn-primary submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Add Employee Modal -->



        <!-- Update Employee Modal -->
        <div id="edit_employee" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Update Employee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('all/employee/update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="e_id" value="">
                            <div class="row">
                                <div class="col-sm-12">
                                    <h4>Basic Information</h4>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                    <label class="col-form-label">Full Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" id="employee_name" name="name" placeholder="Employee Full Name">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Employee Unique ID <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="employee_employee_id" name="employee_id" placeholder="Employee Unique ID">
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Iqama Number <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="employee_ecoma_number" name="ecoma_number" placeholder="Ecoma Number">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Iqama Type <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="employee_ecoma_type" name="ecoma_type" placeholder="Ecoma Type">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Iqama Expiry <span class="text-danger">*</span></label>
                                        <input class="form-control datetimepicker" type="text" id="employee_ecoma_expiry" name="ecoma_expiry" placeholder="Ecoma Expiry">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Job Title <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="employee_job_title" name="job_title" placeholder="Job Title">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Company / Site <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="employee_company_site" name="company_site" placeholder="Company / Site">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Contact <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="employee_contact" name="contact" placeholder="Contact Number">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Email <span class="text-danger">*</span></label>
                                        <input class="form-control" type="email" id="employee_email" name="email" placeholder="Auto email">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Nationality <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" id="employee_nationality" name="nationality" placeholder="Nationality">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-12">
                                    <h4>Bank Details</h4>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label">Bank Name Code <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="employee_bank_name_code" name="bank_name_code" placeholder="Bank Name Code">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="col-form-label"> Bank Address<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="employee_bank_address" name="bank_address" placeholder="Bank Address">
                                    </div>
                                </div>
                                <div class="form-group">
                                        <label class="col-form-label"> Account<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="employee_account" name="account" placeholder="Bank Account">
                                    </div>
                                </div>
                            </div>
                            <div class="submit-section">
                                <button class="btn btn-primary submit-btn">Update</button>
                            </div>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Add Employee Modal -->


    </div>
    <!-- /Page Wrapper -->
    <?php $__env->startSection('script'); ?>

    
    <script>
        $(document).on('click','.edit_employee',function()
        {
            var _this = $(this).parents('tr');
            $('#e_id').val(_this.find('.id').text());
            $('#employee_name').val(_this.find('.employee_name').text());
            $('#employee_ecoma_number').val(_this.find('.employee_ecoma_number').text());
            $('#employee_ecoma_type').val(_this.find('.employee_ecoma_type').text());
            $('#employee_ecoma_expiry').val(_this.find('.employee_ecoma_expiry').text());
            $('#employee_email').val(_this.find('.employee_email').text());
            $('#employee_contact').val(_this.find('.employee_contact').text());
            $('#employee_nationality').val(_this.find('.employee_nationality').text());
            $('#employee_bank_name_code').val(_this.find('.employee_bank_name_code').text());
            $('#employee_company_site').val(_this.find('.employee_company_site').text());
            $('#employee_account').val(_this.find('.employee_account').text());
            $('#employee_job_title').val(_this.find('.employee_job_title').text());
            $('#employee_bank_address').val(_this.find('.employee_bank_address').text());
            $('#employee_employee_id').val(_this.find('.employee_employee_id').text());

        });
    </script>
    
    <script>
        $(document).on('click','.delete_project',function()
        {
            var _this = $(this).parents('tr');
            $('.e_id').val(_this.find('.id').text());
        });
    </script>



    <script>
        $("input:checkbox").on('click', function()
        {
            var $box = $(this);
            if ($box.is(":checked"))
            {
                var group = "input:checkbox[class='" + $box.attr("class") + "']";
                $(group).prop("checked", false);
                $box.prop("checked", true);
            }
            else
            {
                $box.prop("checked", false);
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.select2s-hidden-accessible').select2({
                closeOnSelect: false
            });
        });
    </script>

    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.1\htdocs\hrmsserver\resources\views/form/allemployeecard.blade.php ENDPATH**/ ?>